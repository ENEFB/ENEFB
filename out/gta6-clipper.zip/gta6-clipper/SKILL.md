---
name: "gta6-clipper"
description: "GTA 6 stream clipper: finds big GTA 6 streams, picks viral moments, and makes ready-to-post 9:16 clips with facecam, hook title and captions, plus POST.md. Use for clipping GTA/GTA 6 streams or VODs."
---

# GTA 6 Clipper

Streams in, ready-to-post vertical clips out. **You run it; the user only gives links (or nothing: `--find`).**
`SKILL` = the folder this file is in. The command is `bash SKILL/scripts/gta6clip` (macOS, and on Windows
inside Claude Code, whose shell is Git Bash). In a Windows cmd/PowerShell window: `SKILL\scripts\gta6clip.cmd`.
Everything it makes goes to `~/gta6-clips/<date>/<streamer>__<stream title>/` (on Windows
`C:\Users\<name>\gta6-clips\...`; if the user folder has non-English letters, `C:\gta6clip\gta6-clips\...`).

## 0. First use on a machine
- **macOS**: `bash SKILL/scripts/setup.sh` until it prints **All set**. Install what's missing the free, official
  way (`brew install ffmpeg deno`); ask before anything needing a password.
- **Windows 10/11**: `powershell -ExecutionPolicy Bypass -File SKILL/scripts/setup.ps1` (or double-click
  `setup.cmd`) until it prints **All set**. It installs ffmpeg, Deno and uv with winget, makes the Python env with
  Python 3.11, tests which GPU encoder really works (NVIDIA NVENC → Intel Quick Sync → AMD AMF → CPU) and says
  which `--parallel` fits the PC. If it installed programs, restart Claude Code so its shell sees them.
Both: private Python env in `~/.gta6-clipper`; Whisper tiny + base (~220 MB) and the facecam finder (0.2 MB).

## 1. What happens to each stream
1. **Audio only** of the whole stream is downloaded (a 4-hour stream ≈ 200-300 MB; video is NOT downloaded).
2. **Listen**: a fast local transcript (Whisper tiny) + loudness per second (yelling, screaming = spikes) + on
   YouTube replays, chat speed per 5 s (chat going off).
3. **Pick**: Claude (`claude -p`, the user's subscription) reads the transcript in 12-minute parts, 4 at a time,
   with `[LOUD +NdB]` and `[CHAT xN]` marks, and returns the strongest moments: `first_reaction`, `discovery`,
   `reaction`, `funny`, `take`, each with a hook title, caption, hashtags and a 1-100 score. Best N per stream kept.
4. **Make**: for each pick, only that minute of video is downloaded (1080p), lined up with the stream audio to the
   frame, framed 9:16 (facecam found automatically → cam on top, gameplay below; big face → follow it; no face →
   whole frame on blur), hook bar on the seam, exact word-by-word captions (Whisper base), loudness −14 LUFS.
5. `POST.md` (paste-ready caption + hashtags + where in the stream), `clips.json`, `report.json` (time per stage).

## 2. Run it
Run long jobs in the background and tell the user what's happening in plain words.
```bash
bash SKILL/scripts/gta6clip URL                      # one stream, 3 clips
bash SKILL/scripts/gta6clip URL URL URL --clips 4    # several streams, 2 at a time
bash SKILL/scripts/gta6clip --find --list            # just show today's biggest GTA streams
bash SKILL/scripts/gta6clip --find --streams 7       # find them and clip them (~21 clips)
bash SKILL/scripts/gta6clip URL --section "2:00:00-4:00:00"   # only part of a long stream
```
| flag | use |
|---|---|
| `--clips N` | clips per stream (default 3) |
| `--streams N` | with `--find`: how many streams (default 5) |
| `--parallel N` | streams at the same time (default 2; 3+ on a strong Mac) |
| `--section A-B` | only that part (`h:mm:ss-h:mm:ss`); for live streams, clip the new hours only |
| `--cookies X` | use a login: **needed for Kick** and sub-only Twitch VODs. macOS: `chrome`. **Windows: `firefox`** (sign in there) or a `cookies.txt` path; Chrome/Edge lock their cookies on Windows |
| `--layout stream/face/fit` | force a look (default `auto` decides per clip) |
| `--model sonnet` | a lighter Claude model for picking, to save usage |
| `--cpu` | encode on the CPU even if a GPU works (GPU is the default when it passes a test encode; `--fast` is kept as a no-op) |
| `--redo` | pick the moments again (keeps the downloaded audio) |
| `--keep-audio` | keep the audio after clipping (default: deleted to save disk) |

Re-running the same command resumes: finished steps are cached in `~/gta6-clips/work/`.

## 3. Finding streams (`--find`)
Sources, biggest first, one per streamer:
- **YouTube**: today's most-viewed long streams for "GTA 6 stream" (no key needed).
- **Watchlist** `~/gta6-clips/streamers.txt` (`twitch:login`, `youtube:@handle`): each one's newest VOD from the
  last 36 h with "GTA" in the title. Edit this list with the user: add the streamers they clip for.
- **Twitch top live GTA 6 streams**: only with the user's own free Twitch app key. Steps: dev.twitch.tv/console →
  Register Your Application (any name, redirect `http://localhost`, category Other) → copy Client ID, make a Client
  Secret → put `TWITCH_CLIENT_ID=...` and `TWITCH_CLIENT_SECRET=...` in `~/gta6-clips/.env`.
Before Nov 19 2026 the finder mostly returns GTA 5 / countdown streams; from launch it's GTA 6.

## 4. Launch day playbook (GTA 6 unlocks Nov 19, 2026 at midnight local time; PS5 + Xbox Series)
- The night before: `--find --list` to see who's live; add the big GTA streamers to the watchlist.
- Every 2-3 hours: `--find --streams 7` (a live stream is clipped up to "now"; next run use `--section` from where
  the last run stopped, the times are in `report.json`). Offer to set this up with /loop.
- First hours = **first reactions** (the opening, the first drive, the map, the first police chase). Post those first.
- A clip earns most in its first hours: post as soon as clips are out; watch each one before posting.

## 5. Before the user posts
Open each clip (or a frame from it) and check: the facecam crop shows the face, captions are readable, the hook bar
names the right streamer. The user posts; never post for them. `POST.md` has the caption for each.
Settings live in `~/gta6-clips/config.json` (any key from `scripts/clipper/config.py`, e.g. `clip lengths`,
`claude_parallel`, `cam_height`, caption colours).

## 6. Problems
- **"Sign in to confirm your age"** (many GTA streams on YouTube) → `--cookies chrome` on macOS (keychain asks
  once); on Windows `--cookies firefox` (signed into YouTube/Kick/Twitch in Firefox) or `--cookies C:\path\cookies.txt`.
  **Kick 403** and **Twitch sub-only VODs** → same. "could not decrypt" / "cookie database" → Chrome/Edge on Windows: use Firefox.
- **Windows: GPU stopped working after a driver change** → delete `~/gta6-clips/work/encoder.txt`; the next run re-tests.
- **Windows: "'claude' not found"** → Claude Code isn't on PATH in that window; run from Claude Code or open a new terminal.
- **Windows: the PC sleeps mid-run** → it shouldn't: the clipper keeps Windows awake while it works (screen may turn off).
- **"sound match weak"** on a clip → the clip may be a second off; re-run with `--redo` or check that clip.
- **Slow listening** → long streams take ~1-2 min per hour of stream on an M-series Mac, a bit more on most
  Windows PCs (Whisper uses all real CPU cores); use `--section`.
- **Claude found nothing** → low-energy stream; try another stream or `--clips` lower.
- **Disk** → ~0.1 GB per stream hour while working; audio is deleted after the clips are made.